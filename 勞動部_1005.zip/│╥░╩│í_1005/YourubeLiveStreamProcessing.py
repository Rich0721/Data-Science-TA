# Usage: python YourubeLiveStreamProcessing.py https://www.youtube.com/watch?v=iVpOdRU0r9s

import os
import time
import sys

from datetime import datetime


# url = "https://www.youtube.com/watch?v=iVpOdRU0r9s"

def get_stream(url):
	countCatchImageNum = 0
# 每 5 秒抓一張 Live Stream
	while True:
		countCatchImageNum += 1
		fileNowName = datetime.now().strftime('%Y-%m-%d_%H%M%S')
		instruction = "streamlink -O " + url + " 1080p | ffmpeg -i - -f image2 -r 1/2 -frames:v 1 " + fileNowName + ".jpg"
		print (instruction) 
		os.system(instruction)
		move_instruction = "move " + fileNowName + ".jpg ./Data/"
		os.system(move_instruction)
		print (move_instruction)
		time.sleep(5)
		print ("已經抓取:" + str(countCatchImageNum) + " 張")

# 主程式 - Main function
if __name__=="__main__":

	if len(sys.argv) != 2:
		print("Usage: python3 " + sys.argv[0] + " File Name: Ex. https://www.youtube.com/watch?v=iVpOdRU0r9s")
		exit()
	urlInput = sys.argv[1]  # 取得輸入變數
	get_stream(urlInput)
	